
source("cyrsetup.r") # настройка шрифтов и др. общих параметров графиков

# \chapterX{Предисловие}

# \chapter{Что такое данные и зачем их обрабатывать?}

# \section{Откуда берутся данные}

# \section{Генеральная совокупность и выборка}

# \section{Как получать данные}

# \section{Что ищут в данных}

# \chapter{Как обрабатывать данные}

# \section{Неспециализированные программы}

# \section{Специализированные статистические программы}

# \subsection{Оконно-кнопочные системы}

# \subsection{Статистические среды}

# \section{Из истории \S и \R}

# \section{Применение, преимущества и недостатки \R}

b <- matrix(1:9, ncol=3)

# \section{Как скачать и установить \R}

# \section{Как начать работать в \R}

# \subsection{Запуск}

# \subsection{Первые шаги}

q

# \section{\R и работа с данными: вид снаружи}

# \subsection{Как загружать данные}

a <- c(1,2,3,4,5)

a

b <- 1:5

b

getwd()

getwd()

getwd()

dir("data")

read.table("data/mydata.txt", sep=";", head=TRUE)

read.table("data/mydata.txt", sep=";", head=TRUE,
encoding="UTF-8")

read.table("data/mydata2.txt", sep=";", head=TRUE)

read.table("data/mydata3.txt", dec=",", sep=";", h=T)

x <- "apple"

save(x, file="x.rd") # Сохранить объект "x"

exists("x")

rm(x)

exists("x")

dir()

load("x.rd") # Загрузить объект "x"

x

# \subsection{Как сохранять результаты}

write.table(file="trees.csv", trees, row.names=FALSE, sep=";",
quote=FALSE)

sink("1.txt", split=TRUE)

2+2

sink()

print("2+2")

2+2

# \subsection{\R как калькулятор}

# \subsection{Графики}

pdf(file="pics/05430.pdf"); oldpar <- par(mar=c(2,2,2,1))

plot(1:20, main="Заголовок")

legend("topleft", pch=1, legend="Мои любимые точки")

par(oldpar); dev.off(); embedCMFonts("pics/05430.pdf")

pdf(file="pics/05610.pdf"); oldpar <- par(mar=c(2,2,2,1))

plot(cars)

title(main="Автомобили двадцатых годов")

par(oldpar); dev.off(); embedCMFonts("pics/05610.pdf")

pdf(file="pics/05960.pdf"); oldpar <- par(mar=c(2,2,1,1))

library(ggplot2)

qplot(1:20, 1:20, main="Заголовок")

par(oldpar); dev.off(); embedCMFonts("pics/05960.pdf")

# \subsection{Графические устройства}

png(file="1-20.png", bg="transparent")

plot(1:20)

dev.off()

pdf("1-20.pdf", family="NimbusSan", encoding="CP1251.enc")

plot(1:20, main="Заголовок")

dev.off()

embedFonts("1-20.pdf")

# \subsection{Графические опции}

pdf(file="pics/06060.pdf"); oldpar <- par(mar=c(2,2,0,1))

old.par <- par(mfrow=c(2,1))

hist(cars$speed, main="")

hist(cars$dist, main="")

par(old.par)

par(oldpar); dev.off(); embedCMFonts("pics/06060.pdf")

# \subsection{Интерактивная графика}

# \chapter{Типы данных}

# \section{Градусы, часы и километры: интервальные данные}

x <- c(174, 162, 188, 192, 165, 168, 172.5)

str(x)

is.vector(x)

is.numeric(x)

# \section{<<Садись, двойка>>: шкальные данные}

# \section{Красный, желтый, зеленый: номинальные данные}

sex <- c("male", "female", "male", "male", "female", "male",
"male")

is.character(sex)

is.vector(sex)

str(sex)

sex

sex[1]

table(sex)

sex.f <- factor(sex)

sex.f

pdf(file="pics/08830.pdf"); oldpar <- par(mar=c(2,2,1,1))

plot(sex.f)

par(oldpar); dev.off(); embedCMFonts("pics/08830.pdf")

is.factor(sex.f)

is.character(sex.f)

str(sex.f)

sex.f[5:6]

sex.f[6:7]

sex.f[6:7, drop=TRUE]

factor(as.character(sex.f[6:7]))

as.numeric(sex.f)

w <- c(69, 68, 93, 87, 59, 82, 72)

pdf(file="pics/09290.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(x, w, pch=as.numeric(sex.f), col=as.numeric(sex.f))

legend("topleft", pch=1:2, col=1:2, legend=levels(sex.f))

par(oldpar); dev.off(); embedCMFonts("pics/09290.pdf")

m <- c("L", "S", "XL", "XXL", "S", "M", "L")

m.f <- factor(m)

m.f

m.o <- ordered(m.f, levels=c("S", "M", "L", "XL", "XXL"))

m.o

a <- factor(3:5)

a

as.numeric(a) # Неправильно!

as.numeric(as.character(a)) # Правильно!

# \section{Доли, счет и ранги: вторичные данные}

pdf(file="pics/09860.pdf"); oldpar <- par(mar=c(2,2,0,1))

romashka.t <- read.table("data/romashka.txt", sep="\t")

romashka <- romashka.t$V2

names(romashka) <- romashka.t$V1

oldpar <- par(mar = c(7, 4, 4, 2) + 0.1)

romashka.plot <- barplot(romashka, names.arg="")

text(romashka.plot, par("usr")[3]-0.25, srt=45, adj=1,
xpd=TRUE, labels=names(romashka))

par(oldpar)

par(oldpar); dev.off(); embedCMFonts("pics/09860.pdf")

pdf(file="pics/10070.pdf"); oldpar <- par(mar=c(2,2,3,1))

dotchart(romashka)

par(oldpar); dev.off(); embedCMFonts("pics/10070.pdf")

a1 <- c(1,2,3,4,4,5,7,7,7,9,15,17)

a2 <- c(1,2,3,4,5,7,7,7,9,15,17)

names(a1) <- rank(a1)

a1

names(a2) <- rank(a2)

a2

wilcox.test(a2)

# \section{Пропущенные данные}

h <- c(8, 10, NA, NA, 8, NA, 8)

h

mean(h)

mean(h, na.rm=TRUE)

mean(na.omit(h))

h[is.na(h)] <- mean(h, na.rm=TRUE)

h

h.old <- h

h.old

# \section{Выбросы и как их найти}

# \section{Меняем данные: основные принципы преобразования}

a <- 1:10

b <- seq(100, 1000, 100)

d <- data.frame(a, b)

d

scale(d)

# \section{Матрицы, списки и таблицы данных}

# \subsection{Матрицы}

m <- 1:4

m

ma <- matrix(m, ncol=2, byrow=TRUE)

ma

str(ma)

str(m)

mb <- m

mb

attr(mb, "dim") <- c(2,2)

mb

m3 <- 1:8

dim(m3) <- c(2,2,2)

m3

# \subsection{Списки}

l <- list("R", 1:3, TRUE, NA, list("r", 4))

l

h[3]

 ma[2, 1]

l[1]

str(l[1])

l[[1]]

str(l[[1]])

names(l) <- c("first", "second", "third", "fourth", "fifth")

l$first

str(l$first)

names(w) <- c("Коля", "Женя", "Петя", "Саша", "Катя", "Вася",
"Жора")

w

rownames(ma) <- c("a1","a2")

colnames(ma) <- c("b1","b2")

ma

w["Женя"]

# \subsection{Таблицы данных}

d <- data.frame(weight=w, height=x, size=m.o, sex=sex.f)

d

str(d)

d$weight

d[[1]]

d[,1]

d[,"weight"]

d[,2:4]

d[,-1]

d[d$sex=="female",]

d$sex=="female"

d[order(d$sex, d$height), ]

ma <- matrix(m, ncol=2, byrow=FALSE)

ma

d.sorted <- d[order(d$sex, d$height), ]

d.sorted[, order(names(d.sorted))]

rev(sort(romashka))

# \chapter{Великое в малом: одномерные данные}

# \section{Как оценивать общую тенденцию}

salary <- c(21, 19, 27, 11, 102, 25, 21)

mean(salary); median(salary)

a1 <- c(1,2,3,4,4,5,7,7,7,9,15,17)

a2 <- c(1,2,3,4,5,7,7,7,9,15,17)

median(a1)

median(a2)

sex <- c("male", "female", "male", "male", "female", "male",
"male")

t.sex <- table(sex)

mode <- t.sex[which.max(t.sex)]

mode

attach(trees) # Первый способ

mean(Girth)

mean(Height)

mean(Volume/Height)

detach(trees)

with(trees, mean(Volume/Height)) # Второй способ

lapply(trees, mean) # Третий способ

sd(salary); var(salary); IQR(salary)

attach(trees)

mean(Height)

median(Height)

sd(Height)

IQR(Height)

detach(trees)

pdf(file="pics/14390.pdf"); oldpar <- par(mar=c(2,2,0,1))

new.1000 <- sample((median(salary) - IQR(salary)) :
(median(salary) + IQR(salary)), 1000, replace=TRUE)

salary2 <- c(salary, new.1000)

boxplot(salary2, log="y")

par(oldpar); dev.off(); embedCMFonts("pics/14390.pdf")

pdf(file="pics/14560.pdf"); oldpar <- par(mar=c(2,2,0,1))

boxplot(trees)

par(oldpar); dev.off(); embedCMFonts("pics/14560.pdf")

pdf(file="pics/14730.pdf"); oldpar <- par(mar=c(2,2,0,1))

hist(salary2, breaks=20, main="")

par(oldpar); dev.off(); embedCMFonts("pics/14730.pdf")

table(cut(salary2, 20))

stem(salary, scale=2)

pdf(file="pics/15260.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(density(salary2, adjust=2), main="")

rug(salary2)

par(oldpar); dev.off(); embedCMFonts("pics/15260.pdf")

pdf(file="pics/15580.pdf"); oldpar <- par(mar=c(2,2,0,1))

library("beeswarm")

beeswarm(trees)

boxplot(trees, add=TRUE)

par(oldpar); dev.off(); embedCMFonts("pics/15580.pdf")

lapply(list(salary, salary2), summary)

summary(attenu)

100*sapply(trees, sd)/colMeans(trees)

# \section{Ошибочные данные}

dir("data")

err <- read.table("data/errors.txt", h=TRUE, sep="\t",
stringsAsFactors=TRUE)

str(err)

summary(err)

# \section{Одномерные статистические тесты}

t.test(salary, mu=mean(salary))

wilcox.test(salary2, mu=median(salary2), conf.int=TRUE)

shapiro.test(salary)

shapiro.test(salary2)

set.seed(1638)

shapiro.test(rnorm(100))

pdf(file="pics/17030.pdf"); oldpar <- par(mar=c(2,2,0,1))

qqnorm(salary2, main="")

qqline(salary2, col=2)

par(oldpar); dev.off(); embedCMFonts("pics/17030.pdf")

ks.test(salary2, "pnorm")

# \section{Как создавать свои функции}

normality <- function(data.f)
{
result <- data.frame(var=names(data.f), p.value=rep(0,
ncol(data.f)), normality=is.numeric(names(data.f)))
for (i in 1:ncol(data.f))
  {
  data.sh <- shapiro.test(data.f[, i])$p.value
  result[i, 2] <- round(data.sh, 5)
  result[i, 3] <- (data.sh > .05)
  }
return(result)
}

normality(trees)

normality2 <- function(data.f, p=.05)
{
nn <- ncol(data.f)
result <- data.frame(var=names(data.f), p.value=numeric(nn),
normality=logical(nn))
for (i in 1:nn)
  {
  data.sh <- shapiro.test(data.f[, i])$p.value
  result[i, 2:3] <- list(round(data.sh, 5), data.sh > p)
  }
return(result)
}

normality2(trees)

normality2(trees, 0.1)

lapply(trees, shapiro.test)

lapply(trees, function(.x) ifelse(shapiro.test(.x)$p.value >
.05, "NORMAL", "NOT NORMAL"))

normality3 <- function(df, p=.05)
{
lapply(df, function(.x) ifelse(shapiro.test(.x)$p.value >
p, "NORMAL", "NOT NORMAL"))
}

normality3(list(salary, salary2))

normality3(log(trees+1))

# \section{Всегда ли точны проценты}

binom.test(x=356, n=476, p=0.7, alternative="two.sided")

prop.test(x=356, n=476, p=0.7, alternative="two.sided")

str(shapiro.test(rnorm(100)))

set.seed(1683)

shapiro.test(rnorm(100))$p.value

prop.test(0.48*262, 262)

power.prop.test(p1=0.48, p2=0.52, power=0.8)

# \chapter{Анализ связей: двумерные данные}

# \section{Что такое статистический тест}

# \subsection{Статистические гипотезы}

# \subsection{Статистические ошибки}

# \section{Есть ли различие, или Тестирование двух выборок}

pdf(file="pics/20320.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(extra ~ group, data = sleep)

par(oldpar); dev.off(); embedCMFonts("pics/20320.pdf")

with(sleep, t.test(extra[group == 1], extra[group == 2],
var.equal = FALSE))

wilcox.test(Ozone ~ Month, data = airquality,
subset = Month %in% c(5, 8))

pdf(file="pics/20890.pdf"); oldpar <- par(mar=c(2,2,0,1))

boxplot(Ozone ~ Month, data = airquality,
subset = Month %in% c(5, 8))

par(oldpar); dev.off(); embedCMFonts("pics/20890.pdf")

# \section{Есть ли соответствие, или Анализ таблиц}

with(airquality, table(cut(Temp, quantile(Temp)), Month))

ftable(Titanic, row.vars = 1:3)

d <- factor(rep(c("A","B","C"), 10), levels=c("A","B","C","D",
"E"))

is.na(d) <- 3:4

table(factor(d, exclude = NULL))

pdf(file="pics/21660.pdf"); oldpar <- par(mar=c(2,2,0,1))

titanic <- apply(Titanic, c(1, 4), sum)

titanic

titanic

mosaicplot(titanic, col = c("red", "green"), main = "", 
cex.axis=1)

par(oldpar); dev.off(); embedCMFonts("pics/21660.pdf")

x <- margin.table(HairEyeColor, c(1, 2))

chisq.test(x)

pdf(file="pics/21960.pdf"); oldpar <- par(mar=c(2,2,0,1))

x <- margin.table(HairEyeColor, c(1,2))

assocplot(x)

par(oldpar); dev.off(); embedCMFonts("pics/21960.pdf")

tox <- read.table("data/otravlenie.txt", h=TRUE)

head(tox)

for (m in 2:ncol(tox))
{
tmp <- chisq.test(tox$ILL, tox[,m])
print(paste(names(tox)[m], tmp$p.value))
}

pdf(file="pics/24120.pdf"); oldpar <- par(mar=c(4,4,0,1))

assocplot(table(ILL=tox$ILL, CAESAR=tox$CAESAR))

par(oldpar); dev.off(); embedCMFonts("pics/24120.pdf")

pok <- read.table("data/pokorm_03.dat", h=TRUE, sep=";")

library(psych)

cohen.kappa(pok)

# \section{Есть ли взаимосвязь, или Анализ корреляций}

cor(5:15, 7:17)

cor(5:15, c(7:16, 23))

cor(trees)

x <- rexp(50)

cor(x, log(x), method="spearman")

symnum(cor(longley))

pdf(file="pics/22880.pdf"); oldpar <- par(mar=c(2,3,0,1))

cor.l <- cor(longley)

image(1:ncol(cor.l), 1:nrow(cor.l), cor.l, 
col=heat.colors(22), axes=FALSE, xlab="", ylab="")

axis(1, at=1:ncol(cor.l), labels=abbreviate(colnames(cor.l)))

axis(2, at=1:nrow(cor.l), labels=abbreviate(rownames(cor.l)),
las = 2)

par(oldpar); dev.off(); embedCMFonts("pics/22880.pdf")

pdf(file="pics/23120.pdf"); oldpar <- par(mar=c(2,2,0,1))

library(ellipse)

cor.l <- cor(longley)

colnames(cor.l) <- abbreviate(colnames(cor.l))

rownames(cor.l) <- abbreviate(rownames(cor.l))

plotcorr(cor.l, type="lower", mar=c(0,0,0,0))

par(oldpar); dev.off(); embedCMFonts("pics/23120.pdf")

with(trees, cor.test(Girth, Height))

# \section{Какая связь, или Регрессионный анализ}

pdf(file="pics/23870.pdf"); oldpar <- par(mar=c(4,4,1,1))

women.metr <- women

women.metr$height <- 0.0254*women.metr$height

women.metr$weight <- 0.45359237*women.metr$weight

lm.women<-lm(formula = weight ~ height, data = women.metr)

lm.women$coefficients

b0 <- lm.women$coefficient[1]

b1 <- lm.women$coefficient[2]

x1 <- min(women.metr$height)

x2 <- max(women.metr$height)

x <- seq(from = x1, to = x2, length.out =100)

y <- b0 + b1*x

plot(women.metr$height, women.metr$weight, main="",
xlab="Рост (м)", ylab="Вес (кг)")

grid()

lines(x, y, col="red")

par(oldpar); dev.off(); embedCMFonts("pics/23870.pdf")

summary(lm.women)

vybory <- read.table("data/vybory.txt", h=TRUE)

str(vybory)

head(vybory)

attach(vybory)

DOLJA <- cbind(KAND.1, KAND.2, KAND.3) / IZBIR

JAVKA <- (DEJSTV + NEDEJSTV) / IZBIR

cor(JAVKA, DOLJA)

lm.1 <- lm(KAND.1/IZBIR ~ JAVKA)

lm.2 <- lm(KAND.2/IZBIR ~ JAVKA)

lm.3 <- lm(KAND.3/IZBIR ~ JAVKA)

lapply(list(lm.1, lm.2, lm.3), summary)

pdf(file="pics/27760.pdf"); oldpar <- par(mar=c(4,4,0,1))

plot(KAND.3/IZBIR ~ JAVKA, xlim=c(0,1), ylim=c(0,1), 
xlab="Явка", ylab="Доля проголосовавших за кандидата")

points(KAND.1/IZBIR ~ JAVKA, pch=2)

points(KAND.2/IZBIR ~ JAVKA, pch=3)

abline(lm.3)

abline(lm.2, lty=2)

abline(lm.1, lty=3)

legend("topleft", lty=c(3,2,1),
legend=c("Кандидат 1","Кандидат 2","Кандидат 3"))

detach(vybory)

par(oldpar); dev.off(); embedCMFonts("pics/27760.pdf")

vybory2 <- cbind(JAVKA, stack(data.frame(DOLJA)))

names(vybory2) <- c("javka","dolja","kand")

str(vybory2)

head(vybory2, 3)

ancova.v <- lm(dolja ~ javka * kand, data=vybory2)

summary(ancova.v)

pdf(file="pics/28790.pdf"); oldpar <- par(mar=c(4,4,0,1))

prp.coast <- read.table("data/primula.txt",
as.is=TRUE, h=TRUE)

plot(yfrac ~ nwse, data=prp.coast, type="n",
xlab="Дистанция от Новороссийска, км",
ylab="Пропорция светлых цветков, %")

rect(129, -10, 189, 110, col=gray(.8), border=NA); box()

mtext("129", at=128, side=3, line=0, cex=.8)

mtext("189", at=189, side=3, line=0, cex=.8)

points(yfrac ~ nwse, data=prp.coast)

abline(lm(yfrac ~ nwse, data=prp.coast), lty=2)

lines(loess.smooth(prp.coast$nwse, prp.coast$yfrac), lty=1)

par(oldpar); dev.off(); embedCMFonts("pics/28790.pdf")

# \section{Вероятность успеха, или Логистическая регрессия}

l <- read.table("data/logit.txt", stringsAsFactors=TRUE)

head(l)

l.logit <- glm(formula=V2 ~ V1, family=binomial, data=l)

summary(l.logit)

tox.logit <- glm(formula=I(2-ILL) ~ CAESAR + TOMATO,
family=binomial, data=tox)

tox.logit2 <- update(tox.logit, . ~ . - TOMATO)

tox.logit3 <- update(tox.logit, . ~ . - CAESAR)

tox.logit$aic

tox.logit2$aic

tox.logit3$aic

# \section{Если выборок больше двух}

pdf(file="pics/27420.pdf"); oldpar <- par(mar=c(2,2,0,1))

set.seed(1683)

VES.BR <- sample(70:90, 30, replace=TRUE)

VES.BL <- sample(69:79, 30, replace=TRUE)

VES.SH <- sample(70:80, 30, replace=TRUE)

ROST.BR <- sample(160:180, 30, replace=TRUE)

ROST.BL <- sample(155:160, 30, replace=TRUE)

ROST.SH <- sample(160:170, 30, replace=TRUE)

data <- data.frame(CVET=rep(c("br", "bl", "sh"), each=30),
VES=c(VES.BR, VES.BL, VES.SH),
ROST=c(ROST.BR, ROST.BL, ROST.SH))

boxplot(data$ROST ~ data$CVET)

anova(lm(data$ROST ~ data$CVET))

par(oldpar); dev.off(); embedCMFonts("pics/27420.pdf")

pairwise.t.test(data$ROST, data$CVET)

pdf(file="pics/29880.pdf"); oldpar <- par(mar=c(2,2,0,1))

rost.cvet <- aov(lm(data$ROST ~ data$CVET))

(rost.cvet.hsd <- TukeyHSD(rost.cvet))

plot(rost.cvet.hsd)

par(oldpar); dev.off(); embedCMFonts("pics/29880.pdf")

kruskal.test(data$ROST ~ data$CVET)

a <- c(1, 2, 3, 4, 5, 6, 7, 8, 9)

b <- c(5, 5, 5, 5, 5, 5, 5, 5, 5)

dif <- a-b

pol.dif <- dif[dif > 0]

binom.test(length(pol.dif), length(dif))

ozone.month <- airquality[,c("Ozone","Month")]

ozone.month.list <- unstack(ozone.month)

normality3(ozone.month.list)

normality3(ozone.month[ozone.month$Month==5,][1])

normality3(ozone.month[ozone.month$Month==6,][1])

shapiro.test(ozone.month[ozone.month$Month==5,"Ozone"])

otsenki <- read.table("data/otsenki.txt")

klassy <- split(otsenki$V1, otsenki$V2)

normality3(klassy)

lapply(klassy, function(.x) median(.x, na.rm=TRUE))

wilcox.test(klassy$A1, klassy$A2, paired=TRUE)

wilcox.test(klassy$B1, klassy$A1, alt="greater")

kass <- read.table("data/kass.txt", h=TRUE)

head(kass)

normality3(kass)

(kass.m <- sapply(kass, mean))

with(kass, t.test(KASS.1, KASS.2))

pdf(file="pics/29190.pdf"); oldpar <- par(mar=c(2,4,0,1))

(kass.sd <- sapply(kass, sd))

library(gplots)

barplot2(kass.m, plot.ci=TRUE,
ci.l=kass.m, ci.u=(kass.m + (3 * kass.sd)),
names.arg=c("Первый кассир","Второй кассир"),
ylab="Очередь")

par(oldpar); dev.off(); embedCMFonts("pics/29190.pdf")

pr <- read.table("data/prorostki.txt", h=TRUE)

head(pr)

chisq.test(table(pr[pr$CID %in% c(0,105),]))

chisq.test(table(pr[pr$CID %in% c(0,80),]))

chisq.test(table(pr[pr$CID %in% c(0,63),]))

anova(lm(data$VES ~ data$CVET))

pairwise.t.test(data$VES, data$CVET)

pokaz <- read.table("data/pokaz.txt")

attach(pokaz)

pokaz.logit <- glm(formula=V3 ~ V2, family=binomial)

summary(pokaz.logit)

pdf(file="pics/32450.pdf"); oldpar <- par(mar=c(2,2,0,1))

popytki <- seq(1, 5, 0.081) # ровно 50 значений от 1 до 5

pokaz.p <- predict(pokaz.logit, list(V2=popytki),
type="response")

plot(V3 ~ jitter(V2, amount=.1))

lines(popytki, pokaz.p)

detach(pokaz)

par(oldpar); dev.off(); embedCMFonts("pics/32450.pdf")

pdf(file="pics/26450.pdf"); oldpar <- par(mar=c(2,2,0,1))

cor.test(data$VES, data$ROST)

ves.rost <- lm(data$VES ~ data$ROST)

summary(ves.rost)

plot(data$VES ~ data$ROST)

abline(ves.rost)

par(oldpar); dev.off(); embedCMFonts("pics/26450.pdf")

# \chapter{Анализ структуры: data mining}

# \section{Рисуем многомерные данные}

# \subsection{Диаграммы рассеяния}

library(rgl)

plot3d(iris$Sepal.Length, iris$Sepal.Width, iris$Petal.Length,
col=as.numeric(iris$Species), size=3)

pdf(file="pics/27000.pdf"); oldpar <- par(mar=c(0,0,0,1))

library(lattice)

xyplot(Sepal.Length ~ Petal.Length + Petal.Width | Species,
data=iris, auto.key=TRUE)

par(oldpar); dev.off(); embedCMFonts("pics/27000.pdf")

pdf(file="pics/35270.pdf"); oldpar <- par(mar=c(0,0,0,1))

coplot(dolja ~ javka | kand, data=vybory2)

par(oldpar); dev.off(); embedCMFonts("pics/35270.pdf")

pdf(file="pics/27180.pdf"); oldpar <- par(mar=c(0,0,0,0))

pairs(iris[1:4], pch=21, bg=c("red", "green3", "blue")
[unclass(iris$Species)])

par(oldpar); dev.off(); embedCMFonts("pics/27180.pdf")

# \subsection{Пиктограммы}

pdf(file="pics/27400.pdf"); oldpar <- par(mar=c(2,2,0,1))

stars(mtcars[1:9,1:7], cex=1.2)

par(oldpar); dev.off(); embedCMFonts("pics/27400.pdf")

pdf(file="pics/27580.pdf"); oldpar <- par(mar=c(2,2,0,1))

library(TeachingDemos)

faces(mtcars[1:9,1:7])

par(oldpar); dev.off(); embedCMFonts("pics/27580.pdf")

pdf(file="pics/34390.pdf"); oldpar <- par(mar=c(2,0,0,1), cex.axis=0.8)

measurements <- read.table("data/eq-s.txt", h=TRUE, sep=";")

library(MASS)

parcoord(measurements[,-1],
col=rep(rainbow(54), table(measurements[,1])))

par(oldpar); dev.off(); embedCMFonts("pics/34390.pdf")

# \section{Тени многомерных облаков: анализ главных компонент}

iris.pca <- princomp(scale(iris[,1:4]))

pdf(file="pics/27890.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(iris.pca, main="")

par(oldpar); dev.off(); embedCMFonts("pics/27890.pdf")

summary(iris.pca)

pdf(file="pics/28180.pdf"); oldpar <- par(mar=c(4,4,0,1))

iris.p <- predict(iris.pca)

plot(iris.p[,1:2], type="n", xlab="PC1", ylab="PC2")

text(iris.p[,1:2],
labels=abbreviate(iris[,5],1, method="both.sides"))

par(oldpar); dev.off(); embedCMFonts("pics/28180.pdf")

oldpar <- par()

pdf(file="pics/28360.pdf"); oldpar <- par(mar=c(2,2,2,2))

biplot(iris.pca)

par(oldpar); dev.off(); embedCMFonts("pics/28360.pdf")

par(oldpar)

loadings(iris.pca)

pdf(file="pics/28750.pdf"); oldpar <- par(mar=c(2,2,0,1))

library(ade4)

iris.dudi <- dudi.pca(iris[,1:4], scannf=FALSE)

s.class(iris.dudi$li, iris[,5])

par(oldpar); dev.off(); embedCMFonts("pics/28750.pdf")

iris.between <- bca(iris.dudi, iris[,5], scannf=FALSE)

randtest(iris.between)

# \section[Классификация без обучения, или Кластерный анализ]{Классификация без обучения, или Кластерный анализ}

library(cluster)

iris.dist <- daisy(iris[,1:4], metric="manhattan")

pdf(file="pics/29220.pdf"); oldpar <- par(mar=c(4,4,0,1))

iris.c <- cmdscale(iris.dist)

plot(iris.c[,1:2], type="n", xlab="Dim. 1", ylab="Dim. 2")

text(iris.c[,1:2], labels=abbreviate(iris[,5],1,
method="both.sides"))

par(oldpar); dev.off(); embedCMFonts("pics/29220.pdf")

pdf(file="pics/36340.pdf"); oldpar <- par(mar=c(4,4,0,1))

library(KernSmooth)

est <- bkde2D(iris.c[,1:2], bandwidth=c(.7,1.5))

plot(iris.c[,1:2], type="n", xlab="Dim. 1", ylab="Dim. 2")

text(iris.c[,1:2],
labels=abbreviate(iris[,5],1, method="both.sides"))

contour(est$x1, est$x2, est$fhat, add=TRUE,
drawlabels=FALSE, lty=3)

par(oldpar); dev.off(); embedCMFonts("pics/36340.pdf")

pdf(file="pics/29530.pdf"); oldpar <- par(mar=c(0,2,0,1))

iriss <- iris[seq(1,nrow(iris),5),]

iriss.dist <- daisy(iriss[,1:4])

iriss.h <- hclust(iriss.dist, method="ward.D")

plot(iriss.h, labels=abbreviate(iriss[,5],1,
method="both.sides"), main="")

par(oldpar); dev.off(); embedCMFonts("pics/29530.pdf")

pdf(file="pics/29730.pdf"); oldpar <- par(mar=c(2,2,1,1))

library(pvclust)

irisst <- t(iriss[,1:4])

colnames(irisst) <- paste(abbreviate(iriss[,5], 3),
colnames(irisst))

iriss.pv <- pvclust(irisst, method.dist="manhattan",
method.hclust="ward.D", nboot=100)

plot(iriss.pv, col.pv=c(au=0, bp="darkgreen", edge=0), main="")

par(oldpar); dev.off(); embedCMFonts("pics/29730.pdf")

eq <- read.table("data/eq.txt", h=TRUE)

eq.k <- kmeans(eq[,-1], centers=2)

table(eq.k$cluster, eq$SPECIES)

pdf(file="pics/36040.pdf"); oldpar <- par(mar=c(2,2,0,1))

iris.f <- fanny(iris[,1:4], 3)

plot(iris.f, which=1, main="")

head(data.frame(sp=iris[,5], iris.f$membership))

par(oldpar); dev.off(); embedCMFonts("pics/36040.pdf")

pdf(file="pics/37300.pdf"); oldpar <- par(mar=c(2,2,2,2))

library(MASS)

caith.ru <- caith

row.names(caith.ru) <- abbreviate(c("голубоглазые",
"сероглазые","кареглазые","черноглазые"), 10, method="both")

names(caith.ru) <- abbreviate(c("блондины","рыжие",
"русоволосые","шатены","брюнеты"), 10, method="both")

caith.ru

biplot(corresp(caith.ru, nf = 2))

par(oldpar); dev.off(); embedCMFonts("pics/37300.pdf")

# \section[Классификация с обучением,\\или Дискриминантный анализ]{Классификация с обучением, или Дискриминантный анализ}

library(MASS)

iris.train <- iris[seq(1,nrow(iris),5),]

iris.unknown <- iris[-seq(1,nrow(iris),5),]

iris.lda <- lda(iris.train[,1:4], iris.train[,5])

iris.ldap <- predict(iris.lda, iris.unknown[,1:4])$class

table(iris.ldap, iris.unknown[,5])

misclass <- function(pred, obs) {
tbl <- table(pred, obs)
sum <- colSums(tbl)
dia <- diag(tbl)
msc <- (sum - dia)/sum * 100
m.m <- mean(msc)
cat("Classification table:", "\n")
print(tbl)
cat("Misclassification errors:", "\n")
print(round(msc, 1))
}

misclass(iris.ldap, iris.unknown[,5])

ldam <- manova(as.matrix(iris.unknown[,1:4]) ~ iris.ldap)

summary(ldam, test="Wilks")

pdf(file="pics/30320.pdf"); oldpar <- par(mar=c(4,4,0,1))

iris.lda2 <- lda(iris[,1:4], iris[,5])

iris.ldap2 <- predict(iris.lda2, dimen=2)$x

plot(iris.ldap2, type="n", xlab="LD1", ylab="LD2")

text(iris.ldap2, labels=abbreviate(iris[,5], 1,
method="both.sides"))

par(oldpar); dev.off(); embedCMFonts("pics/30320.pdf")

pdf(file="pics/30520.pdf"); oldpar <- par(mar=c(2,2,0,1))

library(tree)

iris.tree <- tree(iris[,5] ~ ., iris[,-5])

plot(iris.tree)

text(iris.tree)

par(oldpar); dev.off(); embedCMFonts("pics/30520.pdf")

library(randomForest)

set.seed(17)

iris.rf <- randomForest(iris.train[,5] ~ .,
data=iris.train[,1:4])

iris.rfp <- predict(iris.rf, iris.unknown[,1:4])

table(iris.rfp, iris.unknown[,5])

pdf(file="pics/30890.pdf"); oldpar <- par(mar=c(2,2,0,1))

set.seed(17)

iris.urf <- randomForest(iris[,-5])

MDSplot(iris.urf, iris[,5])

par(oldpar); dev.off(); embedCMFonts("pics/30890.pdf")

library(e1071)

iris.svm <- svm(Species ~ ., data = iris.train)

iris.svmp <- predict(iris.svm, iris[,1:4])

table(iris.svmp, iris[,5])

pivo <- read.table("data/pivo-s.txt", h=TRUE)

head(pivo)

pdf(file="pics/38270.pdf"); oldpar <- par(mar=c(0,2,0,1))

library(vegan)

pivo.d <- vegdist(pivo, "jaccard")

plot(hclust(pivo.d, "ward.D"), main="", xlab="", sub="")

par(oldpar); dev.off(); embedCMFonts("pics/38270.pdf")

pdf(file="pics/37980.pdf"); oldpar <- par(mar=c(2,2,0,1))

eq <- read.table("data/eq.txt", h=TRUE, stringsAsFactors=TRUE)

eq.tree <- tree(eq[,1] ~ ., eq[,-1])

plot(eq.tree); text(eq.tree)

par(oldpar); dev.off(); embedCMFonts("pics/37980.pdf")

# \chapter{Узнаем будущее: анализ временных рядов}

# \section{Что такое временные ряды}

# \section{Тренд и период колебаний}

# \section{Построение временного ряда}

dates.df <- data.frame(dates=c("2011-01-01","2011-01-02",
"2011-01-03","2011-01-04","2011-01-05"))

str(dates.df$dates)

dates.1 <- as.Date(dates.df$dates, "%Y-%m-%d")

str(dates.1)

ts(1:10,            # ряд данных
frequency = 4,      # поквартально
start = c(1959, 2)) # начинаем во втором квартале 1959 года

z <- ts(matrix(rnorm(300), 100, 3),
start=c(1961, 1), # начинаем в 1-й месяц 1961 года
frequency=12)     # помесячно

pdf(file="pics/32340.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(z,
plot.type="single", # поместить все ряды на одном графике
lty=1:3)            # типы линий временных рядов

par(oldpar); dev.off(); embedCMFonts("pics/32340.pdf")

leaf <- read.table("data/leaf2-4.txt", head=TRUE,
as.is=TRUE, sep=";")

str(leaf)

summary(leaf)

forma <- ts(leaf$FORM, frequency=36)

str(forma)

pdf(file="pics/33160.pdf"); oldpar <- par(mar=c(4,4,0,1))

(acf(forma, main=""))

par(oldpar); dev.off(); embedCMFonts("pics/33160.pdf")

pdf(file="pics/33310.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(stl(forma, s.window="periodic")$time.series, main="")

par(oldpar); dev.off(); embedCMFonts("pics/33310.pdf")

# \section{Прогноз}

polzovateli <- ts(read.table("data/data.txt")$V3,
start=c(2004,12), frequency=12)

cum.polzovateli <- ts(cumsum(polzovateli),
start=c(2004,12), frequency=12)

pdf(file="pics/34710.pdf"); oldpar <- par(mar=c(2,2,1,1))

oldpar <- par(mfrow=c(2,1))

plot(polzovateli, type="b", log="y", xlab="")

plot(cum.polzovateli, type="b", ylim=c(1,3000), log="y")

par(oldpar)

par(oldpar); dev.off(); embedCMFonts("pics/34710.pdf")

model01 <- arima(cum.polzovateli, order=c(0,0,1))

model02 <- arima(cum.polzovateli, order=c(0,0,2))

model03 <- arima(cum.polzovateli, order=c(0,0,3))

model04 <- arima(cum.polzovateli, order=c(0,0,4))

model05 <- arima(cum.polzovateli, order=c(0,0,5))

model06 <- arima(cum.polzovateli, order=c(0,0,6))

model07 <- arima(cum.polzovateli, order=c(0,0,7))

model08 <- arima(cum.polzovateli, order=c(0,0,8))

model09 <- arima(cum.polzovateli, order=c(0,0,9))

model010 <- arima(cum.polzovateli, order=c(0,0,10))

model011 <- arima(cum.polzovateli, order=c(0,0,11))

model012 <- arima(cum.polzovateli, order=c(0,0,12))

model013 <- arima(cum.polzovateli, order=c(0,0,13))

model014 <- arima(cum.polzovateli, order=c(0,0,14))

pdf(file="pics/35250.pdf"); oldpar <- par(mar=c(4,4,1,1))

plot(AIC(model01, model02, model03, model04, model05, model06,
model07, model08, model09, model010, model011, model012,
model013, model014), type="b")

par(oldpar); dev.off(); embedCMFonts("pics/35250.pdf")

model012 <- arima(cum.polzovateli, order=c(0,0,12))

model112 <- arima(cum.polzovateli, order=c(1,0,12))

model212 <- arima(cum.polzovateli, order=c(2,0,12))

model312 <- arima(cum.polzovateli, order=c(3,0,12))

model412 <- arima(cum.polzovateli, order=c(4,0,12))

AIC(model012, model112, model212, model312, model412)

model2120 <- arima(cum.polzovateli, order=c(2,0,12))

model2121 <- arima(cum.polzovateli, order=c(2,1,12))

model2122 <- arima(cum.polzovateli, order=c(2,2,12))

model2123 <- arima(cum.polzovateli, order=c(2,3,12))

model2124 <- arima(cum.polzovateli, order=c(2,4,12))

model2125 <- arima(cum.polzovateli, order=c(2,5,12))

AIC(model2120, model2121 ,model2122, model2123, model2124)

pdf(file="pics/35900.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(cum.polzovateli, # Накопленное число пользователей
xlim=c(2004.7,2010), ylim=c(0,6500))

lines(predict(model2123, n.ahead=12, se.fit = TRUE)$pred,
col="green")

lines(predict(model2123, n.ahead=12, se.fit = TRUE)$se +
predict(model2123, n.ahead=12, se.fit = TRUE)$pred, 
col="red")

lines(-predict(model2123, n.ahead=12, se.fit = TRUE)$se +
predict(model2123, n.ahead=12, se.fit = TRUE)$pred, 
col="red")

par(oldpar); dev.off(); embedCMFonts("pics/35900.pdf")

round(predict(model2123,
n.ahead=12,          # период прогноза
se.fit = TRUE)$se +  # берем из объекта только ошибку
predict(model2123,   # складываем ошибку и данные прогноза
n.ahead=12,
se.fit = TRUE)$pred) # берем только данные самого прогноза

round(-predict(model2123, n.ahead=12, se.fit = TRUE)$se +
predict(model2123, n.ahead=12, se.fit = TRUE)$pred)

uvl <- ts(leaf$K.UVL, frequency=36)

str(uvl)

acf(uvl)

plot(stl(uvl, s.window="periodic")$time.series)

dollar1 <- read.table("data/dollar.txt", dec=",")$V3

dollar <- ts(dollar1[1:56], frequency=7)

for (m in 1:7)
{
mm <- paste("model0", m, sep="")
assign(mm, arima(dollar, order=c(0,0,m)))
cat(paste(mm, ": ", AIC(get(mm)), "\n", sep=""))
}

for (m in 0:5)
{
mm <- paste("model", m, "05", sep="")
assign(mm, arima(dollar, order=c(m,0,5)))
cat(paste(mm, ": ", AIC(get(mm)), "\n", sep=""))
}

for (m in 0:5)
{
mm <- paste("model0", m, "5", sep="")
assign(mm, arima(dollar, order=c(0,m,5)))
cat(paste(mm, ": ", AIC(get(mm)), "\n", sep=""))
}

pdf(file="pics/43990.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(dollar, xlim=c(1,11), ylim=c(27.3,28.5))

lines(predict(model005, n.ahead=14, se.fit = TRUE)$pred,
lty=2)

lines(ts(dollar1[56:70], start=9, frequency=7))

par(oldpar); dev.off(); embedCMFonts("pics/43990.pdf")

# \chapter{Статистическая разведка}

# \section{Первичная обработка данных}

# \section{Окончательная обработка данных}

# \section{Отчет}

Sweave("test-Sweave.Rnw")

citation()

# \chapter{Пример работы в \R}

dir("data")

data <- read.table("data/zhuki.txt", h=TRUE)

data.2 <- read.table("data/zhuki_zap.txt", h=TRUE, dec=",")

data.3 <- data.frame(POL=sample(0:1, 100, replace=TRUE),
CVET=sample(1:3, 100, replace=TRUE),
VES=sample(20:120, 100, replace=TRUE),
ROST=sample(50:150, 100, replace=TRUE))

data

str(data)

data.f <- data[data$POL == 0,]

data.m.big <- data[data$POL == 1 & data$ROST > 10,]

data$VES.R <- data$VES/data$ROST

write.table(data, "data/zhuki_new.txt", quote=FALSE)

summary(data)

summary(data$VES)

min(data$VES)

max(data$VES)

median(data$VES)

mean(data$VES)

colMeans(data)

mean(data, na.rm=TRUE)

data.o <- na.omit(data)

sum(data$VES)

sum(data[2,])

apply(data, 1, sum)

table(data$POL)

100*table(data$POL)/length(data$POL)

round(100*table(data$POL)/length(data$POL), 0)

sd(data$VES)

100*sd(data$VES)/mean(data$VES)

tapply(data$VES, data$POL, mean)

table(data$CVET, data$POL)

100*table(data$CVET, data$POL)/sum(data$CVET, data$POL)

tapply(data$VES, list(data$POL, data$CVET), mean)

hist(data$VES, breaks=20)

hist(data$VES, breaks=c(seq(0,100,20)))

qqnorm(data$VES); qqline(data$VES)

plot(data$ROST, data$VES, type="p")

plot(data$ROST, data$VES, type="p", cex=0.5)

plot(data$ROST, data$VES, type="p", cex=2)

pdf(file="pics/47690.pdf"); oldpar <- par(mar=c(2,2,0,1))

pchShow(c("*",".","+"), cex = 2)

par(oldpar); dev.off(); embedCMFonts("pics/47690.pdf")

plot(data$ROST, data$VES, type="p", pch=2)

plot(data$ROST, data$VES, type="n")

text(data$ROST, data$VES, labels=data$POL)

plot(data$ROST, data$VES, type="n")

text(data$ROST, data$VES, labels=data$POL, col=data$POL+1)

plot(data$ROST, data$VES, type="n")

points(data$ROST, data$VES, pch=data$POL)

pdf(file="pics/52050.pdf"); oldpar <- par(mar=c(4,4,1,1))

plot(data$ROST, data$VES, type="n", xlab="Рост", ylab="Вес")

text(data$ROST, data$VES,
labels=ifelse(data$POL, "\\MA", "\\VE"),
vfont=c("serif","plain"), cex=1.5)

par(oldpar); dev.off(); embedCMFonts("pics/52050.pdf")

plot(data$ROST, data$VES, type="n")

text(data$ROST, data$VES, pch=data$POL, col=data$POL+1)

legend(50, 100, c("male", "female"), pch=c(0,1), col=c(1,2))

dev.copy(png, filename="graph.png")

dev.off()

png("data.png")

dev.off()

plot(data[order(data$ROST), c("ROST", "VES")], type="o")

plot(data[order(data$CVET), c("CVET", "VES")], type="o",
ylim=c(5, 15))

lines(data[order(data$CVET), c("CVET", "ROST")], lty=3)

boxplot(data$ROST)

boxplot(data$ROST ~ factor(data$POL))

t.test(data$VES, data$ROST, paired=TRUE)

t.test(data$VES, data$ROST, paired=FALSE)

t.test(data$VES ~ data$POL)

wilcox.test(data$VES, data$ROST, paired=TRUE)

oneway.test(data$VES ~ data$CVET)

pairwise.t.test(data$VES, data$CVET, p.adj="bonferroni")

kruskal.test(data$VES ~ data$CVET)

chisq.test(data$CVET, data$POL)

prop.test(c(sum(data$POL)), c(length(data$POL)), 0.5)

cor.test(data$VES, data$ROST, method="pearson")

cor.test(data$VES, data$ROST, method="spearman")

anova(lm(data$ROST ~ data$POL))

# \chapter{Графический интерфейс (GUI) для \R}

# \section{\R Сommander}

# \section{RStudio}

# \section{RKWard}

# \section{Revolution-\R}

# \section{JGR}

# \section{Rattle}

# \section{\texttt{rpanel}}

# \section{ESS и другие IDE}

# \chapter{Основы программирования в \R}

# \section{Базовые объекты языка \R}

# \subsection{Вектор}

v <- vector(mode = "logical", length = 0)

c(5.0i, -1.3+8.73i, 2.0)

v1 <- numeric(length = 0)

v2 <- character(length = 0)

v3 <- complex(length = 0)

v4 <- logical(length = 0)

# \subsection{Список}

l <- vector(mode = "list", length = 3)

l <- list(c(1, 5, 7), "string", c(TRUE, FALSE))

l <- list(A=c(1, 5, 7), "string", B=c(TRUE, FALSE))

# \subsection{Матрица и многомерная матрица}

a <- array(data = NA, dim = length(data), dimnames = NULL)

m <- matrix(data = NA, nrow = 1, ncol = 1, byrow = FALSE,
dimnames = NULL)

v <- numeric(6)

dim(v) <- c(2, 3); v

# \subsection{Факторы}

f <- factor(c(1, 1, 2, 1, 3), levels = 1:5,
labels=c("A", "B", "C", "D", "E"))

f

f <- factor(c(1, 1, 2, 1, 3), levels = 1:5,
labels = c("A", "B", "C", "D", "E"), ordered = TRUE)

# \subsection{Таблица данных}

data.frame(matrix(1:6, nrow = 2, ncol = 3))

# \subsection{Выражение}

e <- expression((x + y) / exp(z))

x <- 1; y <- 2; z <- 0; eval(e)

e <- expression((x + y) / exp(z))

D(e, "x")

# \section{Операторы доступа к данным}

# \subsection{Оператор \texttt{[} с положительным аргументом}

v <- 1:5

v[1:3]

v <- 1:5

v[10] <- 10

v

# \subsection{Оператор \texttt{[} с отрицательным аргументом}

v <- 1:5

v[-c(1,5)]

# \subsection{Оператор \texttt{[} со строковым аргументом}

v <- 1:5

names(v) <- c("first", "second", "third", "fourth", "fifth")

v

v[c("first", "third")]

# \subsection{Оператор \texttt{[} с логическим аргументом}

v <- 1:50

even <- c(FALSE, TRUE)

v[even]

three <- rep(c(FALSE, FALSE, TRUE), length = length(v))

v[even & three]

v[c(TRUE, NA)] <- 0

v

# \subsection{Оператор \texttt{\$}}

.Machine$double.eps

.Machine$double.ep

names(.Machine)[grep("double.e", names(.Machine))]

.Machine$double.e

l <- list(abc=1:10)

l

l$a

l$a <- 1:3

l

# \subsection{Оператор \texttt{[[}}

l <- list(A=1:10)

cname <- "A"

l$cname

l[[cname]]

l <- list(abc=1:10)

l$a

l[["a"]]

l[["a", exact=FALSE]]

.Machine[[1]]

.Machine[1]

# \subsection{Доступ к табличным данным}

state.x77[1:2, c("Area", "Population")]

state.x77[1:2, "Area"]

state.x77[1:2, "Area", drop=FALSE]

m <- matrix(1:6, nrow = 3)

m

m[2:4]

# \subsection{Пустые индексы}

m <- matrix(1:6, nrow = 3)

m[c(2,3), ]

m[, 2]

 v <- 1:10

 v[] <- 0

v

v <- rep(0, length(v))

# \section{Функции и аргументы}

norm <- function(x) sqrt(x%*%x)

fib <- function(n)
{
if (n<=2) {
if (n>=0) 1 else 0
}
else {
return(Recall(n-1) + Recall(n-2))
}
}

fibonacci <- fib; rm(fib)

fibonacci(10)

f <- function(aa, bb, cc, ab, ..., arg1 = 5, arg2 = 10) {
print(c(aa, bb, cc, ab, arg1, arg2)); print(list(...))
}

f(arg1 = 7, aa = 1, a = 2, ac = 3, 4, 5, 6)

# \section{Циклы и условные операторы}

# \section{\R как СУБД}

recode <- function(var, from, to)
{
x <- as.vector(var)
x.tmp <- x
for (i in 1:length(from)) {x <- replace(x, x.tmp == from[i],
to[i])}
if(is.factor(var)) factor(x) else x
}

replace(rep(1:10,2), c(2,3,5), c("a","b","c"))

recode(rep(1:10,2), c(2,3,5), c("a","b","c"))

locations <- read.table("data/eq-l.txt", h=T, sep=";")

measurements <- read.table("data/eq-s.txt", h=T, sep=";")

head(locations)

head(measurements)

loc.N.POP <- recode(measurements$N.POP, locations$N.POP,
as.character(locations$SPECIES))

head(cbind(species=loc.N.POP, measurements))

# \section{Правила переписывания. Векторизация}

2 + c(3, 5, 7, 11)

c(1, 2) + c(3, 5, 7, 11)

c(1, 2, 3) + c(3, 5, 7, 11)

p <- 1:20

lik <- 0

for (i in 1:length(p))
{
lik <- lik + log(p[i])
}

lik <- sum(log(p))

v <- NULL

v2 <- 1:10

for (i in 1:length(v2))
{
if (v2[i] %% 2 == 0)
{
v <- c(v, v2[i]) # 7 строка
}
}

v <- v2[v2 %% 2 == 0]

(spisok <- strsplit(c("Вот как это делается",
"Другое немного похожее предложение"), " "))

do.call("cbind", spisok)

do.call("rbind", spisok)

# \section{Отладка}

# \section[Элементы объектно-ориентированного\\ программирования в \R]{Элементы объектно-ориентированного программирования в \R}

# \chapter{Выдержки из документации \R}

# \section{Среда \R}

# \section{\R и \S}

# \section{\R и статистика}

# \section{Получение помощи}

# \section{Команды \R}

# \section{Повтор и коррекция предыдущих команд}

# \section{Сохранение данных и удаление объектов}

# \section{Внешнее произведение двух матриц}

# \section{\texttt{c()}}

# \section{Присоединение}

# \section{\texttt{scan()}}

# \section{\R как набор статистических таблиц}

# \section{Область действия}

# \section{Настройка окружения}

# \section{Графические функции}

# \subsection{\texttt{plot()}}

# \subsection{Отображение многомерных данных}

# \subsection[Другие графические функции высокого\\уровня]{Другие графические функции высокого уровня}

# \subsection{Параметры функций высокого уровня}

# \subsection{Низкоуровневые графические команды}

# \subsection{Математические формулы}

# \subsection{Интерактивная графика}

# \subsection{\texttt{par()}}

# \subsection{Список графических параметров}

# \subsection{Края рисунка}

# \subsection{Составные изображения}

# \subsection{Устройства вывода}

# \subsection{Несколько устройств вывода одновременно}

# \section{Пакеты}

# \subsection{Стандартные и сторонние пакеты}

# \subsection{Пространство имен пакета}

# \chapter{Краткий словарь языка \R}

# \chapter{Краткий словарь терминов}

pdf(file="pics/76680.pdf"); oldpar <- par(mar=c(2,2,0,1))

plot(density(rnorm(10^5)), main="",  xlab="", ylab="")

par(oldpar); dev.off(); embedCMFonts("pics/76680.pdf")

# \chapterX{Литература}

# \chapterX{Об авторах}

sessionInfo()
