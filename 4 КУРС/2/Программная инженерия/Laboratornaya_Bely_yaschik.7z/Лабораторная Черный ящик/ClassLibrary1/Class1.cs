﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    public class Equation
    {
        private double x_min, x_max, _a, _b, _dx;
        public double a
        {
            get { return _a; }
            set { _a = value; }
        }
        public double b
        {
            get { return _b; }
            set { _b = value; }
        }
        public double xmin
        {
            get { return x_min; }
            set { x_min = value;}
        }

        public double xmax
        {
            get { return x_max; }
            set { x_max = value; }
        }

        public double dx
        {
            get { return _dx; }
            set { _dx = value; }
        }
        public Equation(double a, double b, double xmin, double xmax, double dx)
        {
            //1
            if (xmin <= 0)
                throw new ArgumentException("Неверное значение xmin");
            else 
                x_min = xmin;

            //2
            if (a * a + b == 0)
                throw new ArgumentException("Неверные параметры a или b");
            else
            {
                _a = a;
                _b = b;
            }

            //3
            if (xmin * xmin == 4 * xmin + 1)
                throw new ArgumentException("Неверное значение xmin");


            //4
            if (dx <= 0)
                throw new ArgumentException("Неверное значение dx");
            else
                _dx = dx;

            //5
            if (xmin > xmax)
                throw new ArgumentException("Неверное значение xmin или xmax (xmin > xmax)");
            else
                x_max = xmax;

            //6
            if (dx > xmax - xmin)
                throw new ArgumentException("Неверное значение dx (dx > xmax-xmin)");
        }

        public static void Calculation(Equation eq, ref List<double> answersX, ref List<double> answersY)
        {
            while (eq.xmin <= eq.xmax)
            {
                answersX.Add(Math.Round(eq.xmin, 2));
                answersY.Add(Math.Round(func1(eq), 3));
                eq.xmin += eq.dx;
            }
        }

        public static double func1(Equation eq)
        {
            return Math.Log((3 * Math.Pow(eq.xmin, 3) - 2 * (Math.Pow(eq.xmin, 2)) + eq.xmin) / Math.Pow(eq.a * eq.a + eq.b, 2)) + eq.a / (Math.Pow(eq.xmin, 3)
                - 4 * Math.Pow(eq.xmin, 2) - eq.xmin);
        }
    }
}
