﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
            [TestMethod]
            public void TestMethod1()
            {
                double[] arr2 = { 1.2, 2.1, 3.4, 5.5, 6.6, 7.7, 8.8, 9.9, 10.1, 32.1 };
                double a = 
                Assert.AreEqual(90, Point.CheckPoints(point1, point2));
            }
    }
}
