﻿namespace game1
{
    partial class Fifteen
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fifteen));
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.button15 = new ComponentLibrary.Button1();
            this.button14 = new ComponentLibrary.Button1();
            this.button13 = new ComponentLibrary.Button1();
            this.button12 = new ComponentLibrary.Button1();
            this.button11 = new ComponentLibrary.Button1();
            this.button10 = new ComponentLibrary.Button1();
            this.button9 = new ComponentLibrary.Button1();
            this.button8 = new ComponentLibrary.Button1();
            this.button7 = new ComponentLibrary.Button1();
            this.button6 = new ComponentLibrary.Button1();
            this.button5 = new ComponentLibrary.Button1();
            this.button4 = new ComponentLibrary.Button1();
            this.button3 = new ComponentLibrary.Button1();
            this.button2 = new ComponentLibrary.Button1();
            this.button1 = new ComponentLibrary.Button1();
            this.button0 = new ComponentLibrary.Button1();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.menu_start = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.gameTimer1 = new ComponentLibrary.GameTimer();
            this.tableLayoutPanel.SuspendLayout();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel.ColumnCount = 4;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.Controls.Add(this.button15, 3, 3);
            this.tableLayoutPanel.Controls.Add(this.button14, 2, 3);
            this.tableLayoutPanel.Controls.Add(this.button13, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.button12, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.button11, 3, 2);
            this.tableLayoutPanel.Controls.Add(this.button10, 2, 2);
            this.tableLayoutPanel.Controls.Add(this.button9, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.button8, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.button7, 3, 1);
            this.tableLayoutPanel.Controls.Add(this.button6, 2, 1);
            this.tableLayoutPanel.Controls.Add(this.button5, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.button4, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.button3, 3, 0);
            this.tableLayoutPanel.Controls.Add(this.button2, 2, 0);
            this.tableLayoutPanel.Controls.Add(this.button1, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.button0, 0, 0);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 4;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(449, 346);
            this.tableLayoutPanel.TabIndex = 0;
            this.tableLayoutPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.LightGray;
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.Location = new System.Drawing.Point(347, 269);
            this.button15.Margin = new System.Windows.Forms.Padding(10);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(91, 66);
            this.button15.TabIndex = 32;
            this.button15.Tag = "15";
            this.button15.Click += new System.EventHandler(this.button0_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.LightGray;
            this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button14.Location = new System.Drawing.Point(235, 269);
            this.button14.Margin = new System.Windows.Forms.Padding(10);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(91, 66);
            this.button14.TabIndex = 31;
            this.button14.Tag = "14";
            this.button14.Click += new System.EventHandler(this.button0_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.LightGray;
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.Location = new System.Drawing.Point(123, 269);
            this.button13.Margin = new System.Windows.Forms.Padding(10);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(91, 66);
            this.button13.TabIndex = 30;
            this.button13.Tag = "13";
            this.button13.Click += new System.EventHandler(this.button0_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.LightGray;
            this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button12.Location = new System.Drawing.Point(11, 269);
            this.button12.Margin = new System.Windows.Forms.Padding(10);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(91, 66);
            this.button12.TabIndex = 29;
            this.button12.Tag = "12";
            this.button12.Click += new System.EventHandler(this.button0_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.LightGray;
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.Location = new System.Drawing.Point(347, 183);
            this.button11.Margin = new System.Windows.Forms.Padding(10);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(91, 65);
            this.button11.TabIndex = 28;
            this.button11.Tag = "11";
            this.button11.Click += new System.EventHandler(this.button0_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.LightGray;
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.Location = new System.Drawing.Point(235, 183);
            this.button10.Margin = new System.Windows.Forms.Padding(10);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(91, 65);
            this.button10.TabIndex = 27;
            this.button10.Tag = "10";
            this.button10.Click += new System.EventHandler(this.button0_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.LightGray;
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Location = new System.Drawing.Point(123, 183);
            this.button9.Margin = new System.Windows.Forms.Padding(10);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(91, 65);
            this.button9.TabIndex = 26;
            this.button9.Tag = "9";
            this.button9.Click += new System.EventHandler(this.button0_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.LightGray;
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.Location = new System.Drawing.Point(11, 183);
            this.button8.Margin = new System.Windows.Forms.Padding(10);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 65);
            this.button8.TabIndex = 25;
            this.button8.Tag = "8";
            this.button8.Click += new System.EventHandler(this.button0_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightGray;
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.Location = new System.Drawing.Point(347, 97);
            this.button7.Margin = new System.Windows.Forms.Padding(10);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(91, 65);
            this.button7.TabIndex = 24;
            this.button7.Tag = "7";
            this.button7.Click += new System.EventHandler(this.button0_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightGray;
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Location = new System.Drawing.Point(235, 97);
            this.button6.Margin = new System.Windows.Forms.Padding(10);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 65);
            this.button6.TabIndex = 23;
            this.button6.Tag = "6";
            this.button6.Click += new System.EventHandler(this.button0_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightGray;
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.Location = new System.Drawing.Point(123, 97);
            this.button5.Margin = new System.Windows.Forms.Padding(10);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 65);
            this.button5.TabIndex = 22;
            this.button5.Tag = "5";
            this.button5.Click += new System.EventHandler(this.button0_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightGray;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(11, 97);
            this.button4.Margin = new System.Windows.Forms.Padding(10);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 65);
            this.button4.TabIndex = 21;
            this.button4.Tag = "4";
            this.button4.Click += new System.EventHandler(this.button0_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightGray;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(347, 11);
            this.button3.Margin = new System.Windows.Forms.Padding(10);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 65);
            this.button3.TabIndex = 20;
            this.button3.Tag = "3";
            this.button3.Click += new System.EventHandler(this.button0_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(235, 11);
            this.button2.Margin = new System.Windows.Forms.Padding(10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 65);
            this.button2.TabIndex = 19;
            this.button2.Tag = "2";
            this.button2.Click += new System.EventHandler(this.button0_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(123, 11);
            this.button1.Margin = new System.Windows.Forms.Padding(10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 65);
            this.button1.TabIndex = 18;
            this.button1.Tag = "1";
            this.button1.Click += new System.EventHandler(this.button0_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.LightGray;
            this.button0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button0.Location = new System.Drawing.Point(11, 11);
            this.button0.Margin = new System.Windows.Forms.Padding(10);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(91, 65);
            this.button0.TabIndex = 17;
            this.button0.Tag = "0";
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_start,
            this.recordsToolStripMenuItem});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(449, 24);
            this.menu.TabIndex = 1;
            this.menu.Text = "StartMenu";
            // 
            // menu_start
            // 
            this.menu_start.Name = "menu_start";
            this.menu_start.Size = new System.Drawing.Size(86, 20);
            this.menu_start.Text = "Начать игру";
            this.menu_start.Click += new System.EventHandler(this.menu_start_Click);
            // 
            // recordsToolStripMenuItem
            // 
            this.recordsToolStripMenuItem.Name = "recordsToolStripMenuItem";
            this.recordsToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(421, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "\r\n";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(360, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Счетчик:\r\n";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(235, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 21);
            this.label4.TabIndex = 5;
            this.label4.Text = "Таймер";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(107, 0);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 6;
            this.button16.Text = "Отмена";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // gameTimer1
            // 
            this.gameTimer1.Location = new System.Drawing.Point(290, -5);
            this.gameTimer1.Name = "gameTimer1";
            this.gameTimer1.Size = new System.Drawing.Size(55, 27);
            this.gameTimer1.TabIndex = 7;
            // 
            // Fifteen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 370);
            this.Controls.Add(this.gameTimer1);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableLayoutPanel);
            this.Controls.Add(this.menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menu;
            this.Name = "Fifteen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пятнашки";
            this.Load += new System.EventHandler(this.FormGame15_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Fifteen_KeyDown);
            this.tableLayoutPanel.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem menu_start;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button16;
        private ComponentLibrary.GameTimer gameTimer1;
        private ComponentLibrary.Button1 button15;
        private ComponentLibrary.Button1 button14;
        private ComponentLibrary.Button1 button13;
        private ComponentLibrary.Button1 button12;
        private ComponentLibrary.Button1 button11;
        private ComponentLibrary.Button1 button10;
        private ComponentLibrary.Button1 button9;
        private ComponentLibrary.Button1 button8;
        private ComponentLibrary.Button1 button7;
        private ComponentLibrary.Button1 button6;
        private ComponentLibrary.Button1 button5;
        private ComponentLibrary.Button1 button4;
        private ComponentLibrary.Button1 button3;
        private ComponentLibrary.Button1 button2;
        private ComponentLibrary.Button1 button1;
        private ComponentLibrary.Button1 button0;
    }
}
