extern char* md1_data;
extern char* md1_proc( void );

